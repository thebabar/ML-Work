__title__ = "Microsoft Recommenders"
__version__ = "2019.06"
__author__ = "RecoDev Team at Microsoft"
__license__ = "MIT"
__copyright__ = "Copyright 2018-present Microsoft Corporation"

# Version synonym
VERSION = __version__
